<?php

class TestController extends Am_Mvc_Controller
{
    function indexAction()
    {
    }
}