<?php

class Am_Session_Ns extends Zend_Session_Namespace
{
    
}
