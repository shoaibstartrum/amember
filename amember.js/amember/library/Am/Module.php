<?php


/**
 * Base class for module bootstrap
 * @package Am_Plugin
 */
class Am_Module extends Am_Plugin_Base
{
    protected $_idPrefix = 'Bootstrap_';
}
