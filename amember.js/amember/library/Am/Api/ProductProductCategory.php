<?php

class Am_Api_ProductProductCategory extends Am_ApiController_Table
{
    function index($request, $response, $args)
    {
        $this->_response->ajaxResponse($this->getDi()->productCategoryTable->getCategoryProducts());
    }
}
