<?php
/**
 * Created by PhpStorm.
 * User: alexander
 * Date: 8/16/19
 * Time: 2:34 PM
 */

class Am_Mvc_Controller_TokenPayment extends Am_Mvc_Controller_CreditCard
{

}
