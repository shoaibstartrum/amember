<?php

class Am_Navigation_Exception extends Am_Exception_InternalError
{
    
}
