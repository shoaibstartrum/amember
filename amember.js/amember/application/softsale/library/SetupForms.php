<?php

class Am_Form_Setup_Softsale extends Am_Form_Setup
{
    function __construct()
    {
        parent::__construct('softsale');
        $this->setTitle(___('Softsale'));
    }

    function initElements()
    {
        $this->addAdvCheckbox('softsale.show_activation_details')
            ->setLabel(___("Show Activation Details\nin user area"));
        $this->addAdvCheckbox('softsale.hide_expired_licenses')
            ->setLabel(___("Hide expired licenses\nin user area"));
        $this->addAdvCheckbox('softsale.hide_disabled_activation')
            ->setLabel(___("Hide disabled activations\nin user area"));
        $this->addAdvCheckbox('softsale.allow_manual_deactivate')
            ->setLabel(___("Allow customers to disable activations\nin user area"));
    }
}