<?php

class Softsale_LicenseController extends Am_Mvc_Controller
{
    public function preDispatch()
    {
        $this->getDi()->auth->requireLogin($this->getDi()->url('softsale/license', false));
    }

    public function indexAction()
    {
        $licenses = $this->getDi()->licenseTable->getForUser($this->getDi()->user, $this->getModule()->getConfig('hide_expired_licenses'));
        $this->view->licenses = $licenses;
        $this->view->hasActivation = false;
        foreach ($licenses as $l) {
            if ($l->getScheme()->hasActivation()) {
                $this->view->hasActivation = true;
                break;
            }
        }

        $files = $this->getDi()->resourceAccessTable->getAllowedResources($this->getDi()->user, SoftsaleFile::ACCESS_TYPE);

        foreach ($files as $k => $file)
        {
            if ($file->hide) { unset($files[$k]); continue; }
            if (!($file->getUploads(true))) { unset($files[$k]); continue; }
        }
        $this->view->files = $files;
        $this->view->display('softsale/licenses.phtml');
    }

    public function downloadAction()
    {
        $files = $this->getDi()->resourceAccessTable->getAllowedResources($this->getDi()->user, SoftsaleFile::ACCESS_TYPE);

        foreach ($files as $k => $file)
        {
            if ($file->hide) { unset($files[$k]); continue; }
            if (!($file->getUploads(true))) { unset($files[$k]); continue; }
        }
        $this->view->files = $files;
        $this->view->display('softsale/downloads.phtml');
    }

    public function disableActivationAction()
    {
        $url = $this->getDi()->surl('softsale/license', false);
        if(!($license_activation_id = $this->getDi()->security->reveal($this->getParam('id'))))
            Am_Mvc_Response::redirectLocation($url);
        if(!($license_activation = $this->getDi()->licenseActivationTable->load($license_activation_id, false)))
            Am_Mvc_Response::redirectLocation($url);
        if(!($license = $this->getDi()->licenseTable->load($license_activation->license_id, false)))
            Am_Mvc_Response::redirectLocation($url);
        if($license->user_id != $this->getDi()->auth->getUserId())
            Am_Mvc_Response::redirectLocation($url);
        $license_activation->disable();
        Am_Mvc_Response::redirectLocation($url . '?_msg=' . ___('License activation has been disabled'));
    }

    function renderActivationAction()
    {
        $id = $this->_request->getInt('id');
        $l = $this->getDi()->licenseTable->findFirstBy([
            'license_id' => $id,
            'user_id' => $this->getDi()->user->pk(),
        ]);
        if (!$l)
            throw new Am_Exception_Db_NotFound("Incorrect license_id");
        /* @var $l License */
        if (!$l->needActivation())
            throw new Am_Exception_InputError("This license does not require activation");
        $manualActivator = $l->getScheme()->getActivator()->getManualActivator();
        if (!$manualActivator)
            throw new Am_Exception_InputError("This license does not support manual activation");
        return $manualActivator->render($l, $this->_request);
    }
}