<?php
/**
 * @table paysystems
 * @id networkmerchants
 * @title Network Merchants
 * @visible_link http://www.networkmerchants.com/
 * @recurring cc
 * @logo_url networkmerchants.png
 * @am_payment_api 6.0
 */
class Am_Paysystem_Networkmerchants extends Am_Paysystem_Nmi
{
    const PLUGIN_STATUS = self::STATUS_BETA;
    const PLUGIN_DATE = '$Date$';
    const PLUGIN_REVISION = '6.2.9';    
    
    protected $defaultTitle = "Network Merchants Inc";
    protected $defaultDescription  = "e-commerce payment gateway enables companies to process online transactions in real-time anywhere in the world";
    
    function getCustomerVaultVariable()
    {
        return 'nmi-reference-transaction';
    }

    function getGatewayURL()
    {
        return 'https://secure.networkmerchants.com/api/transact.php';
    }
    
    
}