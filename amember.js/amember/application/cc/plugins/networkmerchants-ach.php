<?php
/**
 * @am_payment_api 6.0
*/
class Am_Paysystem_NetworkmerchantsAch extends Am_Paysystem_NmiEcheck
{
    const PLUGIN_STATUS = self::STATUS_BETA;
    const PLUGIN_DATE = '$Date$';
    const PLUGIN_REVISION = '6.2.9';


    protected $defaultTitle = "Network Merchants Inc";
    protected $defaultDescription  = "direct payments";

    function getCustomerVaultVariable()
    {
        return 'nmi-echeck-reference-transaction';
    }


    function getGatewayURL()
    {
        return 'https://secure.networkmerchants.com/api/transact.php';
    }

}
