<script type="text/javascript">
    // this file is here for compatibility only
    document.querySelectorAll('form')
        .forEach(function(form){ amCountryState.initDefaults(form); });
</script>
