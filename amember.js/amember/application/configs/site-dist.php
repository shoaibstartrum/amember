<?php

if (!defined('INCLUDED_AMEMBER_CONFIG')) 
    die("Direct access to this location is not allowed");
  
/*
*  aMember Pro site customization file
*
*  Rename this file to site.php and put your site customizations, 
*  such as fields additions, custom hooks and so on to this file
*  This file will not be overwritten during upgrade
*                                                                               
*/


