You can upload files to this folder via FTP
to make them available later for your users
