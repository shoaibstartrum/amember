<?php

require_once 'bootstrap.php';

if (Am_Di::getInstance()->plugins_misc->isEnabled('ivp')) {
	$ivpPlugin = Am_Di::getInstance()->plugins_misc->loadGet('ivp');

	$userData = (array) Am_Di::getInstance()->auth->getUser();
	if (!$userData) {
		$loginURL = 'login';
	} else {
		$subdomain = explode('.', $_SERVER['HTTP_HOST'])[0];
		if ($subdomain == 'wwwx') {
			$appDomain = 'app' . substr($_SERVER['HTTP_HOST'], 3);
			$loginURL = preg_replace('#//.+?/#', '//' . $appDomain . '/', $ivpPlugin->getLoginURL($userData));
		} else {
			$loginURL = str_replace('{{subdomain}}', $subdomain, $ivpPlugin->getLoginURL($userData));
		}
	}

	header('Location: ' . $loginURL);

} else {
	// plugin error
	//header('Location: member');
	echo "Plugin not enabled\n";

}