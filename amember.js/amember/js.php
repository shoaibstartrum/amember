<?php

/* nop - replaced with new admin.js */